//
//  PropertyDescriptionProtocol.swift
//  Final_Chintan
//
//  Created by CP on 22/01/25.
//

import Foundation

protocol PropertyDescriptionProtocol {
    func showPropertyInfo()
    func getCommission() -> Double
}
