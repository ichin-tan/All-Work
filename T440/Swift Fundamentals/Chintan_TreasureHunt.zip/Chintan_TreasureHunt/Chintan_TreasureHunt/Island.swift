//
//  Island.swift
//  Chintan_TreasureHunt
//
//  Created by CP on 13/01/25.
//

import Foundation

struct Island {
    var name: String
    var isLucky: Bool = false
    var numberOfTreasures: Int
    var specialTreasureNumberInTotalTreasure: Int? = nil
}
