//
//  ContentView.swift
//  Group9_Nature
//
//  Created by CP on 12/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        LoginView()
    }
}

#Preview {
    ContentView()
}
