//
//  Group9_NatureApp.swift
//  Group9_Nature
//
//  Created by CP on 12/02/25.
//

import SwiftUI

@main
struct Group9_NatureApp: App {
        
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
