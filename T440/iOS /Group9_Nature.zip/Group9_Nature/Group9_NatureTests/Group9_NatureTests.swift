//
//  Group9_NatureTests.swift
//  Group9_NatureTests
//
//  Created by CP on 12/02/25.
//

import Testing
@testable import Group9_Nature

struct Group9_NatureTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
