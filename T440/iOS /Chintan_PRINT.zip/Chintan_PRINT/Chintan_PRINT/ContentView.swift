//
//  ContentView.swift
//  Chintan_PRINT
//
//  Created by CP on 05/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        OrderFormView()
    }
}

#Preview {
    ContentView()
}
