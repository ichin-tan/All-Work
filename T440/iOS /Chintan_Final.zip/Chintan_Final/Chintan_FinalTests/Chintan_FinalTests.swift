//
//  Chintan_FinalTests.swift
//  Chintan_FinalTests
//
//  Created by CP on 11/02/25.
//

import Testing
@testable import Chintan_Final

struct Chintan_FinalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
