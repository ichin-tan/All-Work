//
//  Chintan_FinalApp.swift
//  Chintan_Final
//
//  Created by CP on 11/02/25.
//

import SwiftUI

@main
struct Chintan_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
