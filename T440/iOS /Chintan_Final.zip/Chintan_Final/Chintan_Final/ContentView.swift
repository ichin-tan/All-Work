//
//  ContentView.swift
//  Chintan_Final
//
//  Created by CP on 11/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        PackageListView()
    }
}

#Preview {
    ContentView()
}
