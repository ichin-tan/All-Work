//
//  Chintan_PRINTTests.swift
//  Chintan_PRINTTests
//
//  Created by CP on 05/02/25.
//

import Testing
@testable import Chintan_PRINT

struct Chintan_PRINTTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
