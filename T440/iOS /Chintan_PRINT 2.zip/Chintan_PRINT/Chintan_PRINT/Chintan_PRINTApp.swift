//
//  Chintan_PRINTApp.swift
//  Chintan_PRINT
//
//  Created by CP on 05/02/25.
//

import SwiftUI

@main
struct Chintan_PRINTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
