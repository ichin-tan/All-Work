package com.example.project_g02.interfaces

interface LessonClickedInterface {
    fun lessonClickOn(position: Int)
}

