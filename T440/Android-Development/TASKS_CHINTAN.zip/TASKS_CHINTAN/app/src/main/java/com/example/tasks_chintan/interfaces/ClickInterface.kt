package com.example.tasks_chintan.interfaces

interface ClickInterface {
    fun btnUpdateClicked(position: Int)
    fun btnDeleteClicked(position: Int)
}